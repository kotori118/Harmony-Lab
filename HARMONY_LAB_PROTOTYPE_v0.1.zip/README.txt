HARMONY LAB PROTOTYPE

この試作は BMSG Universe / BMSG-PJ / BMSG-DB と完全に独立しています。

■ GASへの入れ方
1. Apps ScriptでスクリプトID
   1Ez6JJmwd5bA57X0SUQukw4yWeNh7eVJMpcehhb8gEI_6ycFQ7Qbc19vD
   のプロジェクトを開く
2. Code.gs の中身を、このZIP内の Code.gs で置き換える
3. 「＋」→ HTML → ファイル名を Index にする
4. Index.html の中身を、このZIP内の Index.html で置き換える
5. 保存
6. デプロイ → 新しいデプロイ → 種類「ウェブアプリ」
7. 実行ユーザー：自分
8. アクセスできるユーザー：自分（またはテストに必要な範囲）
9. デプロイURLをiPhoneで開く

■ この版で動くもの
- YouTube IFrame埋め込み
- URL入力 / 動画ロード
- 再生 / 一時停止
- ±5秒
- START / END
- LOOP
- 0.5 / 0.75 / 1.0倍
- パート作成
- RHYTHM TAP
- 鍵盤で音程入力
- ピアノ音プレビュー
- 簡易ピアノロール
- ALL再生

■ まだ入れていないもの
- Universe連携
- スプレッドシート保存
- 歌詞の文字単位選択
- リズムコピー
- SOLO / MUTE / MAIN ON-OFF
- ノート境界ドラッグ編集
- Draft / Complete保存

これらは、まず操作感を確認してから追加する前提です。